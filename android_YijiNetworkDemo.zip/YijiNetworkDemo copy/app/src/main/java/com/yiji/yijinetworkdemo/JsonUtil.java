package com.yiji.yijinetworkdemo;

import com.google.gson.Gson;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

/**
 * json帮助类
 *
 * @author yanjun
 * @since 0.0.1
 */
public class JsonUtil {

    /**
     * 转换成json string
     *
     * @param obj object
     * @return json string
     * @since 0.0.1
     */
    public static String toJson(Object obj) {
        Gson gson = new Gson();
        return gson.toJson(obj);
    }

    /**
     * 转换成object
     *
     * @param jsonStr json string
     * @param clazz   type
     * @param <T>     object type
     * @return object
     * @since 0.0.1
     */
    public static <T> T fromJson(String jsonStr, Type clazz) {
        Gson gson = new Gson();
        return (T) gson.fromJson(jsonStr, clazz);
    }

    /**
     * 将object转换成map
     *
     * @param entity object
     * @return map
     * @since 0.0.1
     */
    public static Map<String, String> convertToMap(Object entity) {
        Map<String, String> res = new HashMap<>();
        if (null == entity || entity.getClass() == Object.class) {
            return res;
        }

        Field fields[];
        Object value = null;
        for (Class<?> clazz = entity.getClass(); clazz != Object.class; clazz = clazz.getSuperclass()) {
            fields = clazz.getDeclaredFields();
            if (null == fields || 0 >= fields.length) {
                continue;
            }

            for (Field field : fields) {
                if (null == field) {
                    continue;
                }

                if (Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers())) {
                    continue;
                }

                field.setAccessible(true);
                try {
                    value = field.get(entity);
                } catch (IllegalAccessException e) {

                }

                if (null == value) {
                    continue;
                }

                if (value instanceof Byte || value instanceof Character || value instanceof Short ||
                        value instanceof Integer || value instanceof Long || value instanceof Float ||
                        value instanceof Double) {
                    value = String.valueOf(value);
                } else if (value instanceof File) { // ignore file
                    value = null;
                } else if (value instanceof String) { // do nothing

                } else {
                    value = toJson(value);
                }

                if (null != value) {
                    res.put(field.getName(), (String) value);
                }
            }
        }

        return res;

    }

}
