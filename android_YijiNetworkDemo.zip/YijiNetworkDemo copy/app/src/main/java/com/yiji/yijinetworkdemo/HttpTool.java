package com.yiji.yijinetworkdemo;

import android.util.Log;

import java.nio.charset.Charset;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.BufferedSource;

/**
 * ${name} ${description}
 *
 * @author yanjun
 * @since 0.0.1
 */

public class HttpTool {

    /**
     * 生成 orderNo
     *
     * @return
     */
    public static String genOrderNo() {
        return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
    }

    /**
     * 增加公共参数
     *
     * @param params
     */
    public static void addCommonParameters(Map<String, String> params) {
        if (null == params) {
            return;
        }

        if (!params.containsKey("orderNo")) {
            params.put("orderNo", genOrderNo());
        }
    }

    /**
     * 构造请求 url
     *
     * @param url
     * @param params
     * @return
     */
    public static HttpUrl buildUrl(String url, Map<String, String> params) {
        HttpUrl httpUrl = HttpUrl.parse(url);
        if (null == params || 0 == params.size()) {
            return httpUrl;
        }

        HttpUrl.Builder builder = httpUrl.newBuilder();
        String value;
        for (String key : params.keySet()) {
            value = params.get(key);
            if (null == key || "".equals(key) || null == value || "".equals(value)) {
                continue;
            }
            builder.removeAllQueryParameters(key);
            builder.addQueryParameter(key, value);
        }
        return builder.build();
    }

    /**
     * 获取 url 中的请求参数
     *
     * @param url
     * @return
     */
    public static Map<String, String> getParameters(String url) {
        if (null == url || "".equals(url)) {
            return null;
        }
        HttpUrl httpUrl = HttpUrl.parse(url);
        Map<String, String> map = new HashMap<>();
        String value;
        for (String key : httpUrl.queryParameterNames()) {
            value = httpUrl.queryParameter(key);
            if (null == key || "".equals(key) || null == value || "".equals(value)) {
                continue;
            }
            map.put(key, value);
        }

        return map;
    }

    /**
     * 构建一个 HttpClient
     *
     * @return
     */
    public static OkHttpClient newHttpClient() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(30, TimeUnit.SECONDS);
        builder.readTimeout(30, TimeUnit.SECONDS);
        builder.writeTimeout(60, TimeUnit.SECONDS);

        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType)
                                throws
                                CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType)
                                throws CertificateException {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[0];
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
            builder.sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0]);
        } catch (Exception e) {
            Log.e("HttpTool", e.getMessage(), e);
        }

        builder.hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        });

        return builder.build();
    }

    private static final Charset UTF8 = Charset.forName("UTF-8");

    /**
     * 读取 response
     *
     * @param response
     * @return
     */
    public static String readAndCloneResponseBody(Response response) {
        ResponseBody responseBody = response.body();
        return readAndCloneResponseBodyFromBody(responseBody);
    }

    /**
     * 读取 response
     *
     * @param responseBody
     * @return
     */
    public static String readAndCloneResponseBodyFromBody(ResponseBody responseBody) {
        String content = null;
        try {
            Charset charset = UTF8;
            MediaType contentType = responseBody.contentType();
            if (contentType != null) {
                charset = contentType.charset(UTF8);
            }
            BufferedSource source = responseBody.source();
            source.request(Long.MAX_VALUE);
            content = source.buffer().clone().readString(charset);
            return content;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
