package com.yiji.yijinetworkdemo;

import android.util.Log;

import org.json.JSONObject;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * ${name} ${description}
 *
 * @author yanjun
 * @since 0.0.1
 */

public class DefaultParameterSigner implements IParameterSigner {

    private static String securityKey;

    public static String getSecurityKey() {
        return securityKey;
    }

    public static void setSecurityKey(String securityKey) {
        DefaultParameterSigner.securityKey = securityKey;
    }

    @Override
    public String sign(Map<String, String> params) {
        try {
            return genSign(params, getSecurityKey(), "utf-8");
        } catch (Exception e) {
            Log.e("DefaultParameterSigner", e.getMessage(), e);
        }
        return null;
    }

    @Override
    public boolean validate(String json) {
        if (null == json || "".equals(json)) {
            return false;
        }

        try {
            // 将请求结果转换成 map
            JSONObject jsonObject = new JSONObject(json);
            Map<String, String> map = new HashMap<>();
            Iterator<String> keyIterator = jsonObject.keys();
            String key;
            while (keyIterator.hasNext()) {
                key = keyIterator.next();
                map.put(key, jsonObject.opt(key).toString());
            }

            // 移除签名
            String sign = map.remove("sign");

            // 重新生成签名
            String sign1 = genSign(map, getSecurityKey(), "utf-8");

            // 比较
            return sign.equals(sign1);
        } catch (Exception e) {
            Log.e("DefaultParameterSigner", e.getMessage(), e);
        }

        return false;
    }

    /**
     * 生成签名
     *
     * @param dataMap
     * @param securityCheckKey
     * @param charset
     * @return
     * @throws Exception
     */
    private static String genSign(Map<String, String> dataMap, String securityCheckKey, String charset)
            throws Exception {
        StringBuilder sb = new StringBuilder();
        List<Map.Entry<String, String>> sortedKes = getSortedKeySet(dataMap);
        for (Map.Entry<String, String> entry : sortedKes) {
            if (entry.getValue() == null || entry.getKey().equals("sign")) {
                continue;
            }
            sb.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        sb.append(securityCheckKey);
        byte[] toDigest;
        String digest = null;
        try {
            String str = sb.toString();
            toDigest = str.getBytes(charset);
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(toDigest);
            digest = new String(Hex.encodeHex(md.digest()));
        } catch (Exception e) {
            throw new Exception("签名失败", e);
        }
        return digest;
    }

    private static List<Map.Entry<String, String>> getSortedKeySet(Map<String, String> map) {
        ArrayList<Map.Entry<String, String>> lst = new ArrayList<Map.Entry<String, String>>(map.entrySet());

        Collections.sort(lst, new Comparator<Map.Entry<String, String>>() {
            public int compare(Map.Entry<String, String> o1,
                    Map.Entry<String, String> o2) {
                return (o1.getKey().compareTo(o2.getKey()));
            }
        });

        return lst;
    }

}
