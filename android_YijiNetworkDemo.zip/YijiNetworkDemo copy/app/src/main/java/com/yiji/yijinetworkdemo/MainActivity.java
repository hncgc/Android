package com.yiji.yijinetworkdemo;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * ${name} ${description}
 *
 * @author yanjun
 * @since 0.0.1
 */

public class MainActivity extends AppCompatActivity {

    private Button btnRequest;
    private Button btnSign;
    private Button btnValidate;

    private EditText etSecurityKey;
    private EditText etContent;
    private TextView tvResult;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        tvResult = (TextView) findViewById(R.id.tvResult);
        etContent = (EditText) findViewById(R.id.etContent);
        etSecurityKey = (EditText) findViewById(R.id.etSecurityKey);

        btnValidate = (Button) findViewById(R.id.btnValidate);
        btnSign = (Button) findViewById(R.id.btnSign);
        btnRequest = (Button) findViewById(R.id.btnRequest);

        // 设置可滚动
        tvResult.setMovementMethod(ScrollingMovementMethod.getInstance());

        // 设置默认值
        etContent.setText(
                "https://openapi.yijifu.net/gateway.html?partnerId=20140411020055684571&signType=MD5&imageVersion=1.1&protocol=https&appCode=yijiwallet&appDeviceTypeEnum=ANDROID&service=appLatestVersion");
        etSecurityKey.setText("c9cef22553af973d4b04a012f9cb8ea8");

        // 设置事件
        tvResult.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("content", tvResult.getText().toString());
                clipboardManager.setPrimaryClip(clipData);
                Toast.makeText(MainActivity.this, "文本已复制", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        btnRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = etContent.getText().toString();
                if (null == url || "".equals(url)) {
                    tvResult.setText("请输入 url");
                    return;
                }

                String securityKey = etSecurityKey.getText().toString();
                if (null == securityKey || "".equals(securityKey) || "安全码".equals(securityKey)) {
                    tvResult.setText("请输入安全码");
                    return;
                }

                // 保存安全码
                DefaultParameterSigner.setSecurityKey(securityKey);

                // 获取请求参数
                Map<String, String> params = HttpTool.getParameters(url);
                // 增加公共参数
                HttpTool.addCommonParameters(params);
                // 签名
                String sign = Signer.getSigner().sign(params);
                params.put("sign", sign);
                // 构造请求 url
                HttpUrl httpUrl = HttpTool.buildUrl(url, params);
                // 获取 client
                OkHttpClient okHttpClient = HttpTool.newHttpClient();
                // 构造请求
                Request request = new Request.Builder()
                        .url(httpUrl)
                        .build();
                // 请求网络
                okHttpClient.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        Log.e("MainActivity", e.getMessage(), e);
                        postOnUi(new Runnable() {
                            @Override
                            public void run() {
                                tvResult.setText("请求失败!");
                            }
                        });
                    }

                    @Override
                    public void onResponse(Call call, final Response response) throws IOException {
                        postOnUi(new Runnable() {
                            @Override
                            public void run() {
                                String content = HttpTool.readAndCloneResponseBody(response);
                                tvResult.setText("请求结果：" + content);
                            }
                        });
                    }
                });
            }
        });
        btnSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String content = etContent.getText().toString();
                if (null == content || "".equals(content)) {
                    tvResult.setText("请输入 key=value&key=value 这种格式的文本");
                    return;
                }

                Map<String, String> params = convertStringToMap(content);
                if (null == params || 0 == params.size()) {
                    tvResult.setText("请输入 key=value&key=value 这种格式的文本");
                    return;
                }

                String sign = Signer.getSigner().sign(params);
                tvResult.setText("签名结果：" + sign);
            }
        });
        btnValidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String content = etContent.getText().toString();
                if (null == content || "".equals(content) || !isJsonString(content)) {
                    tvResult.setText("请输入 json 格式的文本");
                    return;
                }

                boolean validate = Signer.getSigner().validate(content);
                tvResult.setText("校验签名结果：" + validate);
            }
        });
    }

    /**
     * 将 key=value& 格式的字符串转换成 map
     *
     * @param str
     * @return
     */
    private Map<String, String> convertStringToMap(String str) {
        if (null == str || "".equals(str)) {
            return null;
        }

        String[] arr = str.split("&");
        if (0 == arr.length) {
            return null;
        }

        Map<String, String> map = new HashMap<>();
        String[] pair;
        String key;
        String value;
        for (String line : arr) {
            pair = line.split("=");
            if (null == pair || 2 != pair.length) {
                continue;
            }

            key = pair[0];
            value = pair[1];
            if (null == key || "".equals(key) || null == value || "".equals(value)) {
                continue;
            }

            map.put(key, value);
        }

        return map;
    }

    /**
     * 判断字符串是否是 json 字符串
     *
     * @param str
     * @return
     */
    private boolean isJsonString(String str) {
        if (null == str || "".equals(str)) {
            return false;
        }

        try {
            JsonElement jsonElement = new JsonParser().parse(str);
            return true;
        } catch (JsonParseException e) {

        }
        return false;
    }

    /**
     * 在 UI 线程执行
     *
     * @param task
     */
    private void postOnUi(Runnable task) {
        getWindow().getDecorView().post(task);
    }

}
