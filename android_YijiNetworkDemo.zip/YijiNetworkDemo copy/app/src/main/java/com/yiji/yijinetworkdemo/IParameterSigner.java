package com.yiji.yijinetworkdemo;

import java.util.Map;

/**
 * ${name} ${description}
 *
 * @author yanjun
 * @since 0.0.1
 */

public interface IParameterSigner {

    String sign(Map<String, String> params);

    boolean validate(String json);
}
